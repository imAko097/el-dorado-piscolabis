<div>
    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="<?php echo e($width); ?>"
        height="<?php echo e($height); ?>" viewBox="0 0 256 256" xml:space="preserve">
        <g style="stroke: none; stroke-width: 0; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: none; fill-rule: nonzero; opacity: 1;"
            transform="translate(1.4065934065934016 1.4065934065934016) scale(2.81 2.81)">
            <circle cx="28.744" cy="74.56400000000001" r="10.334"
                style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(51,41,41); fill-rule: nonzero; opacity: 1;"
                transform="  matrix(1 0 0 1 0 0) " />
            <path
                d="M 44.399 45.682 v -4.05 H 27.705 v 2.97 v 1.465 v 9.067 h 7.385 c 3.191 0 5.779 2.587 5.779 5.779 v 3.401 c 0 1.964 1.593 3.557 3.557 3.557 h 5.785 V 55.007 C 50.21 50.912 47.838 47.38 44.399 45.682 z"
                style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(59,101,168); fill-rule: nonzero; opacity: 1;"
                transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" />
            <circle cx="28.744" cy="74.564" r="5.204"
                style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(239,182,90); fill-rule: nonzero; opacity: 1;"
                transform="  matrix(1 0 0 1 0 0) " />
            <circle cx="79.664" cy="74.56400000000001" r="10.334"
                style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(51,41,41); fill-rule: nonzero; opacity: 1;"
                transform="  matrix(1 0 0 1 0 0) " />
            <circle cx="79.66399999999999" cy="74.564" r="5.204"
                style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(239,182,90); fill-rule: nonzero; opacity: 1;"
                transform="  matrix(1 0 0 1 0 0) " />
            <path
                d="M 73.363 34.722 h 0.721 c 0.878 0 1.589 0.711 1.589 1.589 v 7.446 c 0 0.878 -0.711 1.589 -1.589 1.589 h -0.721 c -2.934 0 -5.312 -2.378 -5.312 -5.312 v 0 C 68.051 37.1 70.429 34.722 73.363 34.722 z"
                style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,155,36); fill-rule: nonzero; opacity: 1;"
                transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" />
            <path
                d="M 14.54 73.373 h 55.315 c 0 -5.189 6.539 -11.085 11.085 -11.085 L 65.609 35.399 h -6.216 l 5.445 25.722 c 0.245 1.159 -0.05 2.366 -0.801 3.281 l 0 0 c -0.74 0.901 -1.845 1.423 -3.011 1.423 h -16.6 c -1.964 0 -3.557 -1.592 -3.557 -3.557 v -3.401 c 0 -3.191 -2.587 -5.779 -5.779 -5.779 h -8.374 c -5.671 0 -10.745 3.526 -12.723 8.841 l -2.582 6.94 C 10.598 71.051 12.212 73.373 14.54 73.373 z"
                style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(215,28,34); fill-rule: nonzero; opacity: 1;"
                transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" />
            <path
                d="M 63.812 32.819 h -3.778 v 4.606 c 1.597 0.095 4.084 0.388 5.352 0.975 c 0.539 0.249 1.155 -0.126 1.155 -0.719 v -2.132 C 66.542 34.042 65.32 32.819 63.812 32.819 z"
                style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(246,183,125); fill-rule: nonzero; opacity: 1;"
                transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" />
            <path
                d="M 89.224 67.6 c -1.416 -2.975 -4.105 -5.359 -7.713 -6.239 c -4.68 -1.142 -9.697 0.866 -12.289 4.926 c -1.825 2.859 -2.232 6.088 -1.51 9.004 c 0.153 0.617 0.964 0.767 1.356 0.266 c 4.519 -5.771 12.036 -8.515 19.275 -6.887 C 88.965 68.811 89.498 68.177 89.224 67.6 z"
                style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(193,23,29); fill-rule: nonzero; opacity: 1;"
                transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" />
            <path
                d="M 45.337 33.484 L 45.337 33.484 c 0 3.855 3.125 6.98 6.98 6.98 h 5.979 c 1.525 0 2.761 -1.236 2.761 -2.761 v -4.884 l -4.525 0 c -1.23 0 -2.312 -0.78 -2.729 -1.937 c -1.142 -3.166 -4.752 -6.872 -9.261 -6.872 h 0 c -8.173 0.013 -14.792 6.643 -14.792 14.816 v 5.775 h 10.055 c 1.633 0 3.179 0.376 4.554 1.047 l 0 0.001 c -0.041 -2.131 1.305 -4.261 4.036 -6.392"
                style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(193,23,29); fill-rule: nonzero; opacity: 1;"
                transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" />
            <path
                d="M 59.697 15.373 c 0 5.674 -4.6 10.273 -10.273 10.273 s -11.308 -7.668 -11.308 -13.342 s 5.635 -7.205 11.308 -7.205 S 59.697 9.699 59.697 15.373 z"
                style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,155,36); fill-rule: nonzero; opacity: 1;"
                transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" />
            <path
                d="M 51.279 25.476 c 4.258 -0.777 7.6 -4.177 8.287 -8.467 l -7.756 -1.862 c -1.704 -0.409 -3.213 1.177 -2.72 2.859 L 51.279 25.476 z"
                style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(246,183,125); fill-rule: nonzero; opacity: 1;"
                transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" />
            <path
                d="M 4.404 29.495 h 20.941 c 2.432 0 4.404 1.972 4.404 4.404 v 19.189 H 4.404 C 1.972 53.089 0 51.117 0 48.684 V 33.9 C 0 31.467 1.972 29.495 4.404 29.495 z"
                style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,155,36); fill-rule: nonzero; opacity: 1;"
                transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" />
        </g>
    </svg>
</div><?php /**PATH C:\xampp\htdocs\git\el-dorado-piscolabis\resources\views/components/icono-repartidor.blade.php ENDPATH**/ ?>
<div>
    <img src="<?php echo e(asset('storage/img/eldorado.png')); ?>" alt="Logo" width="100" height="100">
</div>
<?php /**PATH C:\xampp\htdocs\git\el-dorado-piscolabis\resources\views/components/application-logo.blade.php ENDPATH**/ ?>
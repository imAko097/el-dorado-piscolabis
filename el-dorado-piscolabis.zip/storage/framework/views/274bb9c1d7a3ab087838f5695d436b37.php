<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\git\el-dorado-piscolabis\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>
<div class="min-h-screen bg-[#FFF8F0] py-12"> 
    <div class="max-w-7xl mx-auto my-[100px] px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Resumen del pedido -->
            <div class="bg-[#FFFFFF] rounded-lg shadow-lg p-6 border border-[#FCD34D]">
                <div class="flex items-center gap-4 mb-1">
                    <?php if (isset($component)) { $__componentOriginal280a0da1499efec5402d6b0077a50e3d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal280a0da1499efec5402d6b0077a50e3d = $attributes; } ?>
<?php $component = App\View\Components\IconoResumenPedido::resolve(['width' => '50','height' => '50'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icono-resumen-pedido'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\IconoResumenPedido::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal280a0da1499efec5402d6b0077a50e3d)): ?>
<?php $attributes = $__attributesOriginal280a0da1499efec5402d6b0077a50e3d; ?>
<?php unset($__attributesOriginal280a0da1499efec5402d6b0077a50e3d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal280a0da1499efec5402d6b0077a50e3d)): ?>
<?php $component = $__componentOriginal280a0da1499efec5402d6b0077a50e3d; ?>
<?php unset($__componentOriginal280a0da1499efec5402d6b0077a50e3d); ?>
<?php endif; ?>
                    <h2 class="text-xl font-bold text-[#92400E]">RESUMEN DE TU PEDIDO</h2>
                </div>
                
                <div class="space-y-4 mb-6">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center gap-4">
                            <!--[if BLOCK]><![endif]--><?php if($producto['imagen']): ?>
                                <img src="<?php echo e(asset('storage/' . $producto['imagen'])); ?>" alt="<?php echo e($producto['nombre']); ?>" class="w-16 h-16 object-cover rounded-lg">
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <div class="flex-1">
                                <h3 class="font-semibold text-[#1C1917]"><?php echo e(ucfirst($producto['nombre'])); ?></h3>
                                <p class="text-sm text-[#1C1917]">Cantidad: <?php echo e($producto['cantidad']); ?></p>
                                <p class="text-[#92400E] font-medium"><?php echo e(number_format($producto['precio'] * $producto['cantidad'], 2, ',', '.')); ?> €</p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div class="border-t pt-4">
                    <div class="text-right mt-4">
                        <p class="text-sm text-[#1C1917]">Subtotal: <?php echo e(number_format($subtotal, 2, ',', '.')); ?> €</p>
                        <!--[if BLOCK]><![endif]--><?php if($tipoEntrega === 'domicilio'): ?>
                            <p class="text-sm text-[#1C1917]">Entrega a domicilio: <?php echo e(number_format($recargoEntrega, 2, ',', '.')); ?> €</p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <p class="text-sm text-[#1C1917]">IGIC (7%): <?php echo e(number_format($igic, 2, ',', '.')); ?> €</p>
                        <p class="text-lg font-semibold text-[#92400E]">Total: <?php echo e(number_format($total, 2, ',', '.')); ?> €</p>
                    </div>
                </div>
            </div>

            <!-- Formulario de entrega -->
            <div class="bg-[#FFFFFF] rounded-lg shadow-lg p-6 border border-[#FCD34D]">
                <div class="flex items-center gap-4 mb-1">
                    <?php if (isset($component)) { $__componentOriginal263543dff5dc18e6d169469be7ef9256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal263543dff5dc18e6d169469be7ef9256 = $attributes; } ?>
<?php $component = App\View\Components\IconoRepartidor::resolve(['width' => '50','height' => '50'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icono-repartidor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\IconoRepartidor::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal263543dff5dc18e6d169469be7ef9256)): ?>
<?php $attributes = $__attributesOriginal263543dff5dc18e6d169469be7ef9256; ?>
<?php unset($__attributesOriginal263543dff5dc18e6d169469be7ef9256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal263543dff5dc18e6d169469be7ef9256)): ?>
<?php $component = $__componentOriginal263543dff5dc18e6d169469be7ef9256; ?>
<?php unset($__componentOriginal263543dff5dc18e6d169469be7ef9256); ?>
<?php endif; ?>
                    <h2 class="text-xl font-bold text-[#92400E]">DETALLES DE LA ENTREGA</h2>
                </div>
                <h4 class="text-lg mb-4 text-[#1C1917]">Por favor, rellena los siguientes datos.</h4>
                
                <form wire:submit.prevent="realizarPedido" class="space-y-6">
                    <!-- Tipo de entrega -->
                    <div>
                        <label class="block text-sm font-medium text-[#1C1917] mb-2">¿A domicilio o recogida en local?</label>
                        <div class="flex gap-4 text-[#1C1917]">
                            <label class="flex items-center">
                                <input type="radio" wire:model.live="tipoEntrega" value="domicilio" class="mr-2" style="accent-color: #FCD34D;">
                                <span>Entrega a domicilio</span>
                            </label>
                            <label class="flex items-center">
                                <input type="radio" wire:model.live="tipoEntrega" value="local" class="mr-2" style="accent-color: #FCD34D;">
                                <span>Recoger en tienda</span>
                            </label>
                        </div>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tipoEntrega'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Dirección -->
                    <div wire:key="address-field">
                        <!--[if BLOCK]><![endif]--><?php if($tipoEntrega === 'domicilio'): ?>
                            <div>
                                <label for="direccion" class="block text-sm font-medium text-[#1C1917]">Dirección de entrega</label>
                                <div class="grid grid-cols-12 gap-2">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = ['calle' => 'Calle', 'numero' => 'Nº', 'piso' => 'Piso', 'puerta' => 'Puerta']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campo => $placeholder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-span-<?php echo e($campo === 'calle' ? '6' : '2'); ?>">
                                            <input type="text" wire:model.live="<?php echo e($campo); ?>" id="<?php echo e($campo); ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-[#FCD34D] focus:border-[#FCD34D]" placeholder="<?php echo e($placeholder); ?>" maxlength="<?php echo e($campo === 'calle' ? '500' : '2'); ?>">
                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = [$campo];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Teléfono -->
                    <div>
                        <label for="telefono" class="block text-sm font-medium text-[#1C1917]">Teléfono de contacto</label>
                        <input type="tel" wire:model="telefono" id="telefono" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-[#FCD34D] focus:border-[#FCD34D]" placeholder="000000000" maxlength="9">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Forma de pago -->
                    <!--[if BLOCK]><![endif]--><?php if($tipoEntrega === 'domicilio'): ?>
                        <div>
                            <label class="block text-sm font-medium text-[#1C1917] mb-2">Forma de pago</label>
                            <div class="flex gap-4 text-[#1C1917]">
                                <label class="flex items-center">
                                    <input type="radio" wire:model.live="formaPago" value="efectivo" class="mr-2" style="accent-color: #FCD34D;">
                                    <span>Efectivo</span>
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" wire:model.live="formaPago" value="tarjeta" class="mr-2" style="accent-color: #FCD34D;">
                                    <span>Tarjeta</span>
                                </label>
                            </div>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['formaPago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!-- Formulario tarjeta -->
                    <!--[if BLOCK]><![endif]--><?php if($formaPago === 'tarjeta'): ?>
                        <div class="space-y-4 border-t pt-4">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = [
                                ['id' => 'numeroTarjeta', 'label' => 'Número de Tarjeta', 'placeholder' => '1234 5678 9012 3456'],
                                ['id' => 'nombreTitular', 'label' => 'Nombre del Titular', 'placeholder' => 'Como aparece en la tarjeta']
                            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <label for="<?php echo e($field['id']); ?>" class="block text-sm font-medium text-[#1C1917]"><?php echo e($field['label']); ?></label>
                                    <input type="text" wire:model="<?php echo e($field['id']); ?>" id="<?php echo e($field['id']); ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-[#FCD34D] focus:border-[#FCD34D]" placeholder="<?php echo e($field['placeholder']); ?>">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = [$field['id']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                            <div class="grid grid-cols-2 gap-4">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = [
                                    ['id' => 'fechaExpiracion', 'label' => 'Fecha de Expiración', 'placeholder' => 'MM/YY'],
                                    ['id' => 'cvv', 'label' => 'CVV', 'placeholder' => '123']
                                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>
                                        <label for="<?php echo e($field['id']); ?>" class="block text-sm font-medium text-[#1C1917]"><?php echo e($field['label']); ?></label>
                                        <input type="text" wire:model="<?php echo e($field['id']); ?>" id="<?php echo e($field['id']); ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-[#FCD34D] focus:border-[#FCD34D]" placeholder="<?php echo e($field['placeholder']); ?>">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = [$field['id']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!-- Observaciones -->
                    <div>
                        <label for="observaciones" class="block text-sm font-medium text-[#1C1917]">Observaciones</label>
                        <textarea wire:model="observaciones" id="observaciones" rows="3" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-[#FCD34D] focus:border-[#FCD34D]" placeholder="¿Tienes alguna instrucción especial para la entrega? ¡Cuéntanoslo!" maxlength="1000"></textarea>
                    </div>

                    <!-- Botones -->
                    <div class="flex gap-4">
                        <a href="<?php echo e(route('menu')); ?>" class="flex-1 bg-gray-200 text-[#1C1917] text-center py-3 rounded-lg font-semibold hover:bg-gray-300 transition-colors">
                            Volver al menú
                        </a>
                        <button type="submit" class="flex-1 bg-[#FCD34D] text-[#1C1917] text-center py-3 rounded-lg font-semibold hover:bg-[#FCD34D]/90 transition-colors">
                            Realizar pedido
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\git\el-dorado-piscolabis\resources\views/livewire/pedidos/checkout.blade.php ENDPATH**/ ?>
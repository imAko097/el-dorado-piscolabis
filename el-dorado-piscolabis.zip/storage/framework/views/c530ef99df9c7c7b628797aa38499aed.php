<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/inicio/styles.css')); ?>">
    <title>El Dorado - Tu pedido</title>
</head>
<body class="bg-[#FFF8F0] text-[#1C1917]">
    <div>
        <?php if (isset($component)) { $__componentOriginaldd546e2d53ed5b808e199bc6080d55ed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd546e2d53ed5b808e199bc6080d55ed = $attributes; } ?>
<?php $component = App\View\Components\MenuToggle::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu-toggle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MenuToggle::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd546e2d53ed5b808e199bc6080d55ed)): ?>
<?php $attributes = $__attributesOriginaldd546e2d53ed5b808e199bc6080d55ed; ?>
<?php unset($__attributesOriginaldd546e2d53ed5b808e199bc6080d55ed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd546e2d53ed5b808e199bc6080d55ed)): ?>
<?php $component = $__componentOriginaldd546e2d53ed5b808e199bc6080d55ed; ?>
<?php unset($__componentOriginaldd546e2d53ed5b808e199bc6080d55ed); ?>
<?php endif; ?>
    </div>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pedido-confirmacion', ['id' => $id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3814149701-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <!-- Footer -->
    <footer class="bg-white border-t mt-10">
        <div class="max-w-7xl mx-auto px-4 py-6 text-center text-sm text-[#1C1917] space-y-2">
            <div class="flex flex-wrap justify-center gap-4 text-[#92400E]">
                <a href="#" class="hover:underline">Legal</a>
                <a href="#" class="hover:underline">Política de privacidad</a>
                <a href="#" class="hover:underline">Política de cookies</a>
                <a href="#" class="hover:underline">Bases legales promociones y sorteos</a>
                <a href="#" class="hover:underline">Términos y Condiciones</a>
                <a href="#" class="hover:underline">Configuración de cookies</a>
            </div>
            <div class="flex items-center justify-center space-x-2 text-[#92400E]">
                <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#92400E">
                    <path d="M280-80v-366q-51-14-85.5-56T160-600v-280h80v280h40v-280h80v280h40v-280h80v280q0 56-34.5 98T360-446v366h-80Zm400 0v-320H560v-280q0-83 58.5-141.5T760-880v800h-80Z"/>
                </svg>
                <span>Copyright © 2025 El Dorado Piscolabis</span>
            </div>
        </div>
    </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\git\el-dorado-piscolabis\resources\views/pedido/confirmacion.blade.php ENDPATH**/ ?>
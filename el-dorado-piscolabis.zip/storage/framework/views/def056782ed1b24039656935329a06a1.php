<div class="min-h-screen bg-[#FFF8F0] py-10"> 
    <div class="max-w-2xl mx-auto px-4 mt-[105px] sm:px-6 lg:px-8">
        <div class="bg-[#FFFFFF] rounded-lg shadow-lg p-8 text-center border border-[#FCD34D]">
            <div class="mb-1">
                <i class="bi bi-check-circle-fill text-[#15803D] text-6xl"></i>
            </div>

            <h1 class="text-3xl font-bold text-[#92400E] mb-3">¡Pedido Realizado con Éxito!</h1>

            <div class="mb-3">
                <span class="text-[#1C1917]">
                    Tu pedido ha sido registrado correctamente. No salgas de la página para saber el estado de tu pedido.
                </span>
            </div>

            <div class="bg-[#D1FAE5] rounded-lg p-6 mb-6 border border-[#FCD34D]">
                <h2 class="text-xl font-semibold text-[#92400E] mb-4">Detalles del Pedido</h2>
                <div class="space-y-2 text-left text-[#1C1917]">
                    <p><span class="font-bold">Número de pedido:</span> #<?php echo e($pedido->id); ?></p>
                    <p><span class="font-bold">Total:</span> <?php echo e(number_format($pedido->total, 2, ',', '.')); ?> €</p>
                    <p><span class="font-bold">Estado:</span> <?php echo e(ucfirst($pedido->estadoPedido->estado)); ?></p>
                    <!--[if BLOCK]><![endif]--><?php if($pedido->direccion): ?>
                        <p><span class="font-bold">Dirección de entrega:</span> <?php echo e($pedido->direccion); ?></p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <p><span class="font-bold">Teléfono:</span> <?php echo e($pedido->telefono_contacto); ?></p>
                    <!--[if BLOCK]><![endif]--><?php if($pedido->direccion !== 'local'): ?>
                    <p><span class="font-bold">Forma de pago:</span> <?php echo e(ucfirst($pedido->forma_pago)); ?></p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>

            <div>
                <a href="<?php echo e(route('menu')); ?>"
                   class="block w-full bg-[#FFFFFF] text-[#1C1917] text-center py-3 rounded-lg font-semibold border border-[#FCD34D] hover:bg-[#FCD34D] hover:text-[#92400E] transition-colors">
                    Volver al menú
                </a>

                <!--[if BLOCK]><![endif]--><?php if(Auth::check()): ?>
                    <a href="<?php echo e(route('pedidos.mis-pedidos')); ?>"
                       class="block w-full bg-[#FCD34D] text-[#1C1917] text-center py-3 mt-2 rounded-lg font-semibold hover:bg-[#FBBF24] transition-colors">
                        Ver mis pedidos
                    </a>
                <?php else: ?>
                    <div class="mt-3">
                        <span class="text-[#1C1917]">¿No tienes cuenta?
                            <a href="<?php echo e(route('register')); ?>" class="text-[#92400E] font-medium hover:underline">
                                ¡Regístrate para ver tus pedidos!
                            </a>
                            o
                            <a href="<?php echo e(route('login')); ?>" class="text-[#92400E] font-medium hover:underline">
                                ¡Inicia sesión!
                            </a>
                        </span>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\git\el-dorado-piscolabis\resources\views/livewire/pedidos/pedido-confirmacion.blade.php ENDPATH**/ ?>
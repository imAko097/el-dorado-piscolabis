<?php $__env->startComponent('mail::message'); ?>
# Factura del Pedido #<?php echo e($pedido->id); ?>


Hola <?php echo e($usuario->name); ?>,  
Gracias por tu pedido. Aquí tienes los detalles de tu factura:

---

**Fecha del pedido:** <?php echo e($pedido->created_at->format('d/m/Y H:i')); ?>  
**Forma de pago:** <?php echo e(ucfirst($pedido->forma_pago)); ?>  
**Teléfono de contacto:** <?php echo e($pedido->telefono_contacto); ?>  
<?php if($pedido->direccion): ?>  
**Dirección de entrega:** <?php echo e($pedido->direccion); ?>  
<?php endif; ?>

---

## Detalles del pedido

<?php $__env->startComponent('mail::table'); ?>
| Producto | Cantidad | Precio unidad | Total |
|----------|----------|---------------|--------|
<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
| <?php echo e($producto->nombre); ?> | <?php echo e($producto->pivot->cantidad); ?> | <?php echo e(number_format($producto->pivot->precio_unitario, 2, ',', '.')); ?> € | <?php echo e(number_format($producto->pivot->precio_total, 2, ',', '.')); ?> € |
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->renderComponent(); ?>

**Subtotal:** <?php echo e(number_format($pedido->subtotal, 2, ',', '.')); ?> €  
**IGIC (7%):** <?php echo e(number_format($pedido->subtotal * 0.07, 2, ',', '.')); ?> €  
**Total:** **<?php echo e(number_format($pedido->total, 2, ',', '.')); ?> €**

---

Gracias por tu compra.  
Si tienes alguna duda, puedes responder a este correo.

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\git\el-dorado-piscolabis\resources\views/emails/factura.blade.php ENDPATH**/ ?>
<tr>
    <td class="footer" style="text-align: center; padding: 35px 0; color: #999999; font-size: 12px;">
        <p style="font-size: 12px; color: #888;">
        © <?php echo e(date('Y')); ?> Piscolabis El Dorado. Todos los derechos reservados.
        </p>
        <p style="font-size: 12px; color: #aaa;">
        Calle Manuel Alemán Álamo, 35220 Valle de Jinamar, Las Palmas — mrdorado.piscolabis@gmail.com
        </p>
  </td>
</tr>
<?php /**PATH C:\xampp\htdocs\git\el-dorado-piscolabis\resources\views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>
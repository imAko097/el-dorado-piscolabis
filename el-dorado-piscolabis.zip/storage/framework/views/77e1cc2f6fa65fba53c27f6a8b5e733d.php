<?php $__env->startSection('page-title', 'Pedidos'); ?>
<?php $__env->startSection('page-description', 'Administración de pedidos'); ?>
<?php $__env->startSection('styles'); ?>
<script src="https://cdn.tailwindcss.com"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto p-4 py-6">

<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pedidos.lista-pedidos');

$__html = app('livewire')->mount($__name, $__params, 'lw-2261838770-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\git\el-dorado-piscolabis\resources\views/admin/pedido/index.blade.php ENDPATH**/ ?>
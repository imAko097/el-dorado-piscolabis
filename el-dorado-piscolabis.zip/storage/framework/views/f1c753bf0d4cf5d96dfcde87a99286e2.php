<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/inicio/styles.css')); ?>">
    <title>El Dorado - Menú</title>
</head>

<body style="background-color: #FFF8F0;" class="min-h-screen text-[#1C1917]">

    <?php
        $isMenu = request()->routeIs('menu');
        $bgColor = $isMenu ? '#FFFFFF' : 'transparent';
        $colorText = $isMenu ? '#1C1917' : '#FFFFFF';
    ?>

    <script>
        window.menuColors = {
            bgColor: "<?php echo e($bgColor); ?>",
            colorText: "<?php echo e($colorText); ?>"
        };
    </script>

    <?php if (isset($component)) { $__componentOriginaldd546e2d53ed5b808e199bc6080d55ed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd546e2d53ed5b808e199bc6080d55ed = $attributes; } ?>
<?php $component = App\View\Components\MenuToggle::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu-toggle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MenuToggle::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['colorText' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($colorText),'bgColor' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($bgColor)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd546e2d53ed5b808e199bc6080d55ed)): ?>
<?php $attributes = $__attributesOriginaldd546e2d53ed5b808e199bc6080d55ed; ?>
<?php unset($__attributesOriginaldd546e2d53ed5b808e199bc6080d55ed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd546e2d53ed5b808e199bc6080d55ed)): ?>
<?php $component = $__componentOriginaldd546e2d53ed5b808e199bc6080d55ed; ?>
<?php unset($__componentOriginaldd546e2d53ed5b808e199bc6080d55ed); ?>
<?php endif; ?>

    <!-- Contenido -->
    <div class="pt-32 px-6 md:px-40" style="color: #1C1917;">
        <!-- Volver al inicio -->
        <a href="<?php echo e(route('inicio')); ?>"
            class="text-gray-500 flex items-center gap-2 mb-4 hover:text-[#1C1917] hover:underline transition-colors">
            <i class="bi bi-arrow-left"></i>
            Volver
        </a>

        <!-- Carrito -->
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('carrito', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3269433467-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

        <!-- Carta -->
        <h1 class="text-4xl font-bold mb-8 text-center" style="color: #92400E;">NUESTRA CARTA</h1>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('menu', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3269433467-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>

    <!-- Footer -->
    <footer style="background-color: #FFFFFF; border-top: 2px solid #FCD34D;" class="mt-10">
        <div class="max-w-7xl mx-auto px-4 py-6 text-center text-sm text-[#1C1917]">
            <div class="flex flex-wrap justify-center gap-4">
                <a href="#" class="hover:underline" style="color: #92400E;">Legal</a>
                <a href="#" class="hover:underline" style="color: #92400E;">Política de privacidad</a>
                <a href="#" class="hover:underline" style="color: #92400E;">Política de cookies</a>
                <a href="#" class="hover:underline" style="color: #92400E;">Bases legales promociones y sorteos</a>
                <a href="#" class="hover:underline" style="color: #92400E;">Términos y Condiciones</a>
                <a href="#" class="hover:underline" style="color: #92400E;">Configuración de cookies</a>
            </div>
            <div class="flex items-center justify-center space-x-2">
                <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#92400E">
                    <path d="M280-80v-366q-51-14-85.5-56T160-600v-280h80v280h40v-280h80v280h40v-280h80v280q0 56-34.5 98T360-446v366h-80Zm400 0v-320H560v-280q0-83 58.5-141.5T760-880v800h-80Z"/>
                </svg>
                <span>Copyright © 2025 El Dorado Piscolabis</span>
            </div>
        </div>
    </footer>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\git\el-dorado-piscolabis\resources\views/inicio/menu.blade.php ENDPATH**/ ?>
<div class="table">
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</div>
<?php /**PATH C:\xampp\htdocs\git\el-dorado-piscolabis\resources\views/vendor/mail/html/table.blade.php ENDPATH**/ ?>
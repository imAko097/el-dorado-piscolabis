<?php $__env->startComponent('mail::message'); ?>
# ¡Hola <?php echo e($user->name); ?>!

¡Gracias por registrarte en El Dorado!  
Haz clic en el botón de abajo para verificar tu dirección de correo electrónico.

<?php $__env->startComponent('mail::button', ['url' => $url]); ?>
Verificar correo
<?php echo $__env->renderComponent(); ?>

Si no creaste esta cuenta, no es necesario hacer nada.

Gracias,<br>
Equipo de El Dorado

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\git\el-dorado-piscolabis\resources\views/emails/verify.blade.php ENDPATH**/ ?>
import 'jquery';
import './bootstrap';
import 'animate.css';
import './toast.js';
import './carrusel.js';

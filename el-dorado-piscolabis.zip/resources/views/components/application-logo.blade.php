<div>
    <img src="{{ asset('storage/img/eldorado.png') }}" alt="Logo" width="100" height="100">
</div>
